var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_app.js")
R.c("server/chunks/ssr/[root-of-the-server]__80dc2db4._.js")
R.c("server/chunks/ssr/[root-of-the-server]__7cb49907._.js")
R.c("server/chunks/ssr/[root-of-the-server]__1a9fe2c0._.js")
R.m(798225)
module.exports=R.m(798225).exports
