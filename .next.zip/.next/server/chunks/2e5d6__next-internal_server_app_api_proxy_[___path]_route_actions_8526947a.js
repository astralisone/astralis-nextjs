module.exports=[973231,(e,o,d)=>{}];

//# sourceMappingURL=2e5d6__next-internal_server_app_api_proxy_%5B___path%5D_route_actions_8526947a.js.map