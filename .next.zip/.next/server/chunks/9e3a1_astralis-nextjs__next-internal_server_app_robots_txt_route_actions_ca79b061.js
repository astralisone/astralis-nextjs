module.exports=[789857,(e,o,d)=>{}];

//# sourceMappingURL=9e3a1_astralis-nextjs__next-internal_server_app_robots_txt_route_actions_ca79b061.js.map