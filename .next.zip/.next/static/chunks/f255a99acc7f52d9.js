__turbopack_load_page_chunks__("/admin", [
  "static/chunks/2b4e19cbc0924247.js",
  "static/chunks/fbbc6e4482c65a6d.js",
  "static/chunks/a1762c51a721c74b.js",
  "static/chunks/91bf196fb0b708b8.js",
  "static/chunks/eb80d9374396ec54.js",
  "static/chunks/c033c8b70096924d.js",
  "static/chunks/8173c68536de6bcf.js",
  "static/chunks/6f330500b8ae44f2.js",
  "static/chunks/turbopack-261fdb47c484a045.js"
])
