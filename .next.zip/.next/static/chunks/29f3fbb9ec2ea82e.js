__turbopack_load_page_chunks__("/services/data-analytics", [
  "static/chunks/c6e243320ecec70b.js",
  "static/chunks/a1762c51a721c74b.js",
  "static/chunks/8173c68536de6bcf.js",
  "static/chunks/d6f1ab9e1c7f35d9.js",
  "static/chunks/6f330500b8ae44f2.js",
  "static/chunks/8d8c3ad1b160f3e0.js",
  "static/chunks/c033c8b70096924d.js",
  "static/chunks/2a2bee87bf96e019.js",
  "static/chunks/turbopack-2625cb29c92b02ac.js"
])
