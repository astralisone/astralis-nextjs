__turbopack_load_page_chunks__("/admin/EngagementManagementPage", [
  "static/chunks/3791bc220023916e.js",
  "static/chunks/a243bbf44ca108e5.js",
  "static/chunks/eb80d9374396ec54.js",
  "static/chunks/07f42ff5925ae71e.js",
  "static/chunks/8173c68536de6bcf.js",
  "static/chunks/c033c8b70096924d.js",
  "static/chunks/6f330500b8ae44f2.js",
  "static/chunks/ef101e870dea217e.js",
  "static/chunks/cc57960196d6b1ee.js",
  "static/chunks/turbopack-b6e891bffc6b13a9.js"
])
