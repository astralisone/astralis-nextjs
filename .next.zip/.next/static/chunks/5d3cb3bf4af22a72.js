__turbopack_load_page_chunks__("/services/wizard", [
  "static/chunks/a1762c51a721c74b.js",
  "static/chunks/8173c68536de6bcf.js",
  "static/chunks/3c60de2822927527.js",
  "static/chunks/6f330500b8ae44f2.js",
  "static/chunks/c033c8b70096924d.js",
  "static/chunks/8d8c3ad1b160f3e0.js",
  "static/chunks/758fdb897ff0e5fa.js",
  "static/chunks/turbopack-6d184070b43ab533.js"
])
