__turbopack_load_page_chunks__("/forgot-password", [
  "static/chunks/436caeca7e065bee.js",
  "static/chunks/37b559e986c55a74.js",
  "static/chunks/e67212e80ee6c5d5.js",
  "static/chunks/8173c68536de6bcf.js",
  "static/chunks/6f330500b8ae44f2.js",
  "static/chunks/c033c8b70096924d.js",
  "static/chunks/eb80d9374396ec54.js",
  "static/chunks/fdd24c8dea4bd4f0.js",
  "static/chunks/turbopack-157f37c5cb8c8faf.js"
])
