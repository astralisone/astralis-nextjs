__turbopack_load_page_chunks__("/NewsletterPage", [
  "static/chunks/e67212e80ee6c5d5.js",
  "static/chunks/8173c68536de6bcf.js",
  "static/chunks/6f330500b8ae44f2.js",
  "static/chunks/c033c8b70096924d.js",
  "static/chunks/7f798bf91bc38c6c.js",
  "static/chunks/turbopack-f8d9e6e70e9b5f88.js"
])
