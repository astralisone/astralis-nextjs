__turbopack_load_page_chunks__("/services/sales-pipeline", [
  "static/chunks/c6e243320ecec70b.js",
  "static/chunks/a1762c51a721c74b.js",
  "static/chunks/2a2bee87bf96e019.js",
  "static/chunks/124bc41318c9d471.js",
  "static/chunks/6f330500b8ae44f2.js",
  "static/chunks/8d8c3ad1b160f3e0.js",
  "static/chunks/c033c8b70096924d.js",
  "static/chunks/8173c68536de6bcf.js",
  "static/chunks/turbopack-56e6b388ed694f9f.js"
])
