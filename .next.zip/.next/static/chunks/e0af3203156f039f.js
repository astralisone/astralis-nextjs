__turbopack_load_page_chunks__("/WorkflowDemoPage", [
  "static/chunks/3c60de2822927527.js",
  "static/chunks/b03138a1be4d0bbe.js",
  "static/chunks/8173c68536de6bcf.js",
  "static/chunks/6f330500b8ae44f2.js",
  "static/chunks/c033c8b70096924d.js",
  "static/chunks/8d8c3ad1b160f3e0.js",
  "static/chunks/b318c8a5ee93bc1e.js",
  "static/chunks/57027bde993d9cea.js",
  "static/chunks/86129d6c181816bf.css",
  "static/chunks/turbopack-18480b23c3a2475b.js"
])
