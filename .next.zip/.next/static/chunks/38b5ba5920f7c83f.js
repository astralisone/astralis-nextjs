__turbopack_load_page_chunks__("/admin/marketplace", [
  "static/chunks/f4c69e9f2abbfa8f.js",
  "static/chunks/940d2090768262db.js",
  "static/chunks/07f42ff5925ae71e.js",
  "static/chunks/fbbc6e4482c65a6d.js",
  "static/chunks/a1762c51a721c74b.js",
  "static/chunks/8173c68536de6bcf.js",
  "static/chunks/eb80d9374396ec54.js",
  "static/chunks/c033c8b70096924d.js",
  "static/chunks/06b76f5b349a18f8.js",
  "static/chunks/6f330500b8ae44f2.js",
  "static/chunks/0cbd30f9c3290226.js",
  "static/chunks/turbopack-f2a33c1ec441b758.js"
])
