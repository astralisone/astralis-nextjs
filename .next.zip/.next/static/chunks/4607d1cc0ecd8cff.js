__turbopack_load_page_chunks__("/admin/marketplace/[id]/edit", [
  "static/chunks/b7870b760432fe04.js",
  "static/chunks/f4c69e9f2abbfa8f.js",
  "static/chunks/1286f22bc73a5dc8.js",
  "static/chunks/fbbc6e4482c65a6d.js",
  "static/chunks/07f42ff5925ae71e.js",
  "static/chunks/a1762c51a721c74b.js",
  "static/chunks/6f330500b8ae44f2.js",
  "static/chunks/fdd24c8dea4bd4f0.js",
  "static/chunks/8173c68536de6bcf.js",
  "static/chunks/c033c8b70096924d.js",
  "static/chunks/37b559e986c55a74.js",
  "static/chunks/eb80d9374396ec54.js",
  "static/chunks/df75d789a4f32da0.js",
  "static/chunks/turbopack-899d79d0b7abbf0a.js"
])
