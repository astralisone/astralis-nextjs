__turbopack_load_page_chunks__("/_app", [
  "static/chunks/f4c69e9f2abbfa8f.js",
  "static/chunks/aaf1e653262b1946.js",
  "static/chunks/07f42ff5925ae71e.js",
  "static/chunks/a1762c51a721c74b.js",
  "static/chunks/8173c68536de6bcf.js",
  "static/chunks/6f330500b8ae44f2.js",
  "static/chunks/c033c8b70096924d.js",
  "static/chunks/e67212e80ee6c5d5.js",
  "static/chunks/eb80d9374396ec54.js",
  "static/chunks/563540d5d7e6d219.js",
  "static/chunks/495e6529b206f353.css",
  "static/chunks/turbopack-3dee03fcab864441.js"
])
