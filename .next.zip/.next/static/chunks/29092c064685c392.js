__turbopack_load_page_chunks__("/orders", [
  "static/chunks/83ac7f6e6e9f32b6.js",
  "static/chunks/8173c68536de6bcf.js",
  "static/chunks/e2250466be40f134.js",
  "static/chunks/eb80d9374396ec54.js",
  "static/chunks/6f330500b8ae44f2.js",
  "static/chunks/c033c8b70096924d.js",
  "static/chunks/turbopack-f0d4eee577bc0efb.js"
])
