__turbopack_load_page_chunks__("/admin/blog", [
  "static/chunks/3791bc220023916e.js",
  "static/chunks/3b18013450124155.js",
  "static/chunks/8173c68536de6bcf.js",
  "static/chunks/a1762c51a721c74b.js",
  "static/chunks/eb80d9374396ec54.js",
  "static/chunks/6f330500b8ae44f2.js",
  "static/chunks/c033c8b70096924d.js",
  "static/chunks/fbbc6e4482c65a6d.js",
  "static/chunks/76e6d76f5a120180.js",
  "static/chunks/turbopack-cfeaf0271469b5b5.js"
])
