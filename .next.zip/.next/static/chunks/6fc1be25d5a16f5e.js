__turbopack_load_page_chunks__("/admin/blog/tags", [
  "static/chunks/230c2f44917d414a.js",
  "static/chunks/3791bc220023916e.js",
  "static/chunks/a1762c51a721c74b.js",
  "static/chunks/e67212e80ee6c5d5.js",
  "static/chunks/1ccda0be35ae28ec.js",
  "static/chunks/eb80d9374396ec54.js",
  "static/chunks/fdd24c8dea4bd4f0.js",
  "static/chunks/6f330500b8ae44f2.js",
  "static/chunks/8173c68536de6bcf.js",
  "static/chunks/c033c8b70096924d.js",
  "static/chunks/3221a65ecf203778.js",
  "static/chunks/turbopack-a65f8591c7948865.js"
])
