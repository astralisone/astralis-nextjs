# Astralis One — Multi-Agent Engineering System

This repository is a starter scaffold for the Astralis One platform, focused on **AstralisOps v1**.

It includes:

- Next.js 14 + React + TypeScript + Tailwind app (`apps/web`)
- Prisma schema and migrations base (`prisma/schema.prisma`)
- Initial API route handlers for users, orgs, and pipelines (`apps/web/app/api`)
- n8n workflow definition for AI Intake & Lead Routing (`automation/n8n/workflows`)
- Marketplace product package skeletons (`marketplace/`)
- High-level product documentation (`docs/`)

Stack:

- Frontend: Next.js 14 (App Router), React, TypeScript, Tailwind CSS, Inter
- Backend: Next.js API Routes
- ORM: Prisma
- DB: PostgreSQL (DigitalOcean Managed)
- Automation: n8n (DigitalOcean Droplet / container)

