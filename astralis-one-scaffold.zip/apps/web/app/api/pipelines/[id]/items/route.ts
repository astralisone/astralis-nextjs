import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";

const createItemSchema = z.object({
  title: z.string().min(2),
  data: z.any(),
  stageId: z.string(),
});

export async function POST(
  req: NextRequest,
  { params }: { params: { id: string } },
) {
  const body = await req.json();
  const parsed = createItemSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json(
      { error: "Invalid payload", details: parsed.error.flatten() },
      { status: 400 },
    );
  }

  // Optionally: check that stageId belongs to pipeline params.id
  const item = await prisma.pipelineItem.create({
    data: {
      title: parsed.data.title,
      data: parsed.data.data,
      stageId: parsed.data.stageId,
    },
  });

  return NextResponse.json(item, { status: 201 });
}
