import "./globals.css";
import type { ReactNode } from "react";

export const metadata = {
  title: "Astralis One | AstralisOps",
  description: "AI-powered operations automation console.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-[#0A1B2B] text-slate-100 antialiased">
        <div className="flex min-h-screen flex-col">
          <header className="border-b border-slate-800 bg-[#0A1B2B]/95 backdrop-blur">
            <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-4">
              <div className="flex items-center gap-2">
                <span className="h-6 w-6 rounded-full bg-[#2B6CB0]" />
                <span className="text-sm font-semibold tracking-wide">Astralis One</span>
              </div>
              <nav className="flex items-center gap-6 text-sm text-slate-300">
                <a href="/" className="hover:text-white transition-colors">Home</a>
                <a href="/solutions" className="hover:text-white transition-colors">Solutions</a>
                <a href="/astralisops" className="hover:text-white transition-colors">AstralisOps</a>
              </nav>
              <a
                href="/contact"
                className="rounded-md bg-[#2B6CB0] px-3 py-1.5 text-sm font-medium text-white shadow-sm transition hover:bg-[#245a92]"
              >
                Talk to us
              </a>
            </div>
          </header>
          <main className="flex-1">{children}</main>
          <footer className="border-t border-slate-800 bg-[#020617]">
            <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-6 text-xs text-slate-500">
              <span>© {new Date().getFullYear()} Astralis One. All rights reserved.</span>
              <span>AstralisOps · Automation Services · Marketplace</span>
            </div>
          </footer>
        </div>
      </body>
    </html>
  );
}
