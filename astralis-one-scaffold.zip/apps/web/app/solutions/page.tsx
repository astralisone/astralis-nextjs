export default function SolutionsPage() {
  const solutions = [
    {
      title: "Service businesses",
      body: "Unify intake, scheduling, and follow-ups so no lead or request slips through the cracks."
    },
    {
      title: "Agencies & studios",
      body: "Standardize client onboarding, approvals, and delivery workflows with AI-aware pipelines."
    },
    {
      title: "Internal ops teams",
      body: "Give operations teams a single place to see requests, documents, and automation runs."
    }
  ];

  return (
    <div className="mx-auto max-w-6xl px-4 py-12">
      <header className="max-w-2xl">
        <h1 className="text-3xl font-semibold tracking-tight text-white">Solutions for real operations work</h1>
        <p className="mt-4 text-sm text-slate-300">
          AstralisOps is built for teams that live in the messy reality of emails, forms, spreadsheets, and ad-hoc
          processes—and want to bring order without adding headcount.
        </p>
      </header>

      <section className="mt-12 grid gap-6 md:grid-cols-3">
        {solutions.map((s) => (
          <article key={s.title} className="rounded-lg border border-slate-800 bg-slate-900/40 p-4">
            <h2 className="text-sm font-semibold text-white">{s.title}</h2>
            <p className="mt-2 text-xs text-slate-300">{s.body}</p>
          </article>
        ))}
      </section>

      <section className="mt-16 grid gap-8 md:grid-cols-2">
        <div>
          <h2 className="text-xl font-semibold text-white">Common workflows we automate</h2>
          <ul className="mt-4 space-y-2 text-sm text-slate-300">
            <li>• Lead capture → qualification → handoff</li>
            <li>• Client onboarding checklists and document collection</li>
            <li>• Support request triage and escalation</li>
            <li>• Internal approvals and sign-offs</li>
          </ul>
        </div>
        <div className="rounded-lg border border-slate-800 bg-slate-900/40 p-4 text-xs text-slate-300">
          <h3 className="text-sm font-semibold text-white">Outcome-focused, not feature-heavy</h3>
          <p className="mt-2">
            We start with one or two critical flows in your business and get them stable. From there, we expand
            to the rest of your operations with the same patterns.
          </p>
        </div>
      </section>
    </div>
  );
}
