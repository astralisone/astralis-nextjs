export default function HomePage() {
  return (
    <div className="mx-auto max-w-6xl px-4 py-12">
      <section className="grid gap-10 md:grid-cols-2 md:items-center">
        <div>
          <h1 className="text-3xl font-semibold tracking-tight text-white md:text-4xl">
            Automate your operations.<br />Scale without hiring.
          </h1>
          <p className="mt-4 text-sm text-slate-300 md:text-base">
            AstralisOps centralizes intake, scheduling, document processing, and workflows into one AI-driven console
            built for real operators, not lab demos.
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <a
              href="/astralisops"
              className="rounded-md bg-[#2B6CB0] px-4 py-2 text-sm font-medium text-white shadow-sm transition hover:bg-[#245a92]"
            >
              Explore AstralisOps
            </a>
            <a
              href="/contact"
              className="rounded-md border border-slate-700 px-4 py-2 text-sm font-medium text-slate-100 transition hover:border-slate-500"
            >
              Talk to an architect
            </a>
          </div>
        </div>
        <div className="rounded-xl border border-slate-800 bg-slate-900/40 p-4 shadow-sm">
          <div className="mb-3 flex items-center justify-between text-xs text-slate-400">
            <span>Ops Dashboard</span>
            <span>Today</span>
          </div>
          <div className="grid gap-3 md:grid-cols-2">
            <div className="rounded-lg border border-slate-800 bg-slate-900/60 p-3">
              <div className="text-xs text-slate-400">New leads</div>
              <div className="mt-2 text-2xl font-semibold text-white">18</div>
              <div className="mt-1 text-xs text-emerald-400">+32% vs last week</div>
            </div>
            <div className="rounded-lg border border-slate-800 bg-slate-900/60 p-3">
              <div className="text-xs text-slate-400">Automation runs</div>
              <div className="mt-2 text-2xl font-semibold text-white">142</div>
              <div className="mt-1 text-xs text-slate-300">No incidents</div>
            </div>
          </div>
          <div className="mt-4 rounded-lg border border-slate-800 bg-slate-900/60 p-3">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>Active pipelines</span>
              <span className="text-slate-300">Sales · Onboarding · Support</span>
            </div>
            <div className="mt-3 h-2 rounded-full bg-slate-800">
              <div className="h-2 w-2/3 rounded-full bg-[#2B6CB0]" />
            </div>
          </div>
        </div>
      </section>

      <section className="mt-16 space-y-8">
        <div>
          <h2 className="text-xl font-semibold text-white">What AstralisOps does for you</h2>
          <p className="mt-2 text-sm text-slate-300">
            Start with a few critical workflows and grow into a full automation ops console as your needs evolve.
          </p>
        </div>
        <div className="grid gap-6 md:grid-cols-3">
          {[
            {
              title: "AI intake & routing",
              body: "Capture requests from forms, email, or chat and route them into the right pipeline automatically."
            },
            {
              title: "Document automation",
              body: "Turn PDFs, images, and contracts into structured records your team can act on."
            },
            {
              title: "Workflow orchestration",
              body: "Trigger n8n workflows on any event and keep humans in the loop where it matters."
            }
          ].map((card) => (
            <div
              key={card.title}
              className="rounded-lg border border-slate-800 bg-slate-900/40 p-4 text-sm text-slate-200"
            >
              <h3 className="text-sm font-semibold text-white">{card.title}</h3>
              <p className="mt-2 text-xs text-slate-300">{card.body}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
