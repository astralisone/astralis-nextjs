export default function AstralisOpsPage() {
  const features = [
    {
      title: "AI intake & lead routing",
      body: "Turn unstructured requests into structured records and route them to the right pipeline automatically."
    },
    {
      title: "Pipelines & Kanban views",
      body: "Visualize each process as a pipeline with stages, SLAs, and automation on stage changes."
    },
    {
      title: "Document processing",
      body: "Extract key data from PDFs, images, and emails; attach them to the right items and pipelines."
    },
    {
      title: "Scheduling & reminders",
      body: "Offer clean booking flows, reminders, and follow-ups that fit into your existing calendar tools."
    }
  ];

  return (
    <div className="mx-auto max-w-6xl px-4 py-12">
      <header className="grid gap-8 md:grid-cols-2 md:items-center">
        <div>
          <h1 className="text-3xl font-semibold tracking-tight text-white">AstralisOps — AI operations console</h1>
          <p className="mt-4 text-sm text-slate-300">
            One place to see every request, document, and automation run. Built for teams that need reliable, boring
            ops that just work.
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <a
              href="/contact"
              className="rounded-md bg-[#2B6CB0] px-4 py-2 text-sm font-medium text-white shadow-sm transition hover:bg-[#245a92]"
            >
              Schedule a walkthrough
            </a>
            <a
              href="/marketplace"
              className="rounded-md border border-slate-700 px-4 py-2 text-sm font-medium text-slate-100 transition hover:border-slate-500"
            >
              Browse automation kits
            </a>
          </div>
        </div>
        <div className="rounded-xl border border-slate-800 bg-slate-900/40 p-4 shadow-sm">
          <div className="mb-3 text-xs text-slate-400">Pipeline overview</div>
          <div className="grid gap-3 md:grid-cols-3">
            {["Intake", "In progress", "Done"].map((stage, idx) => (
              <div key={stage} className="rounded-lg border border-slate-800 bg-slate-950/40 p-3">
                <div className="text-xs text-slate-400">{stage}</div>
                <div className="mt-2 text-xl font-semibold text-white">{[8, 12, 23][idx]}</div>
              </div>
            ))}
          </div>
        </div>
      </header>

      <section className="mt-16 space-y-8">
        <div>
          <h2 className="text-xl font-semibold text-white">Core capabilities</h2>
          <p className="mt-2 text-sm text-slate-300">
            Start with the essentials and grow into advanced workflows as your team becomes comfortable.
          </p>
        </div>
        <div className="grid gap-6 md:grid-cols-2">
          {features.map((f) => (
            <article key={f.title} className="rounded-lg border border-slate-800 bg-slate-900/40 p-4">
              <h3 className="text-sm font-semibold text-white">{f.title}</h3>
              <p className="mt-2 text-xs text-slate-300">{f.body}</p>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
}
