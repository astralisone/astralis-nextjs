var R=require("../../chunks/[turbopack]_runtime.js")("server/app/robots.txt/route.js")
R.c("server/chunks/[root-of-the-server]__50dbc546._.js")
R.c("server/chunks/[root-of-the-server]__25b3080d._.js")
R.c("server/chunks/9e3a1_astralis-nextjs__next-internal_server_app_robots_txt_route_actions_ca79b061.js")
R.m(482903)
module.exports=R.m(482903).exports
