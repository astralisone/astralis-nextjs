var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__d9c5ed31._.js")
R.c("server/chunks/[root-of-the-server]__25b3080d._.js")
R.c("server/chunks/0780a_next_dist_esm_build_templates_app-route_89cd16ad.js")
R.c("server/chunks/9e3a1_astralis-nextjs__next-internal_server_app_favicon_ico_route_actions_9652771b.js")
R.m(59702)
module.exports=R.m(59702).exports
