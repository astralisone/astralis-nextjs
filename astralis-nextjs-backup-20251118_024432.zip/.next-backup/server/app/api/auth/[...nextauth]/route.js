var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/[...nextauth]/route.js")
R.c("server/chunks/[root-of-the-server]__09fc1316._.js")
R.c("server/chunks/[root-of-the-server]__25b3080d._.js")
R.c("server/chunks/0780a_next_2f1751b7._.js")
R.c("server/chunks/2e5d6__next-internal_server_app_api_auth_[___nextauth]_route_actions_f3aee380.js")
R.m(457057)
module.exports=R.m(457057).exports
