var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/proxy/[...path]/route.js")
R.c("server/chunks/[root-of-the-server]__d75a3159._.js")
R.c("server/chunks/[root-of-the-server]__25b3080d._.js")
R.c("server/chunks/2e5d6__next-internal_server_app_api_proxy_[___path]_route_actions_8526947a.js")
R.m(786742)
module.exports=R.m(786742).exports
