var R=require("../../chunks/[turbopack]_runtime.js")("server/app/sitemap.xml/route.js")
R.c("server/chunks/[root-of-the-server]__e5f534d8._.js")
R.c("server/chunks/[root-of-the-server]__25b3080d._.js")
R.c("server/chunks/9e3a1_astralis-nextjs__next-internal_server_app_sitemap_xml_route_actions_360bb154.js")
R.m(808965)
module.exports=R.m(808965).exports
