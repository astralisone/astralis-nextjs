module.exports=[527535,a=>{"use strict";function b(a){a.languages.hpkp={directive:{pattern:/\b(?:includeSubDomains|max-age|pin-sha256|preload|report-to|report-uri|strict)(?=[\s;=]|$)/i,alias:"property"},operator:/=/,punctuation:/;/}}b.displayName="hpkp",b.aliases=[],a.s(["default",()=>b])}];

//# sourceMappingURL=0780a_refractor_lang_hpkp_a471ff93.js.map