module.exports=[917710,a=>{"use strict";function b(a){a.languages.arff={comment:/%.*/,string:{pattern:/(["'])(?:\\.|(?!\1)[^\\\r\n])*\1/,greedy:!0},keyword:/@(?:attribute|data|end|relation)\b/i,number:/\b\d+(?:\.\d+)?\b/,punctuation:/[{},]/}}b.displayName="arff",b.aliases=[],a.s(["default",()=>b])}];

//# sourceMappingURL=0780a_refractor_lang_arff_befe095b.js.map