module.exports=[694138,(a,b,c)=>{}];

//# sourceMappingURL=9e3a1_astralis-nextjs__next-internal_server_app__global-error_page_actions_6b714210.js.map