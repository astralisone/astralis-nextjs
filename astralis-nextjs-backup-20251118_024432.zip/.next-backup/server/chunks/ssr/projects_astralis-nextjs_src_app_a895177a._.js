module.exports=[970671,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},508174,a=>{"use strict";let b={src:a.i(970671).default,width:256,height:256};a.s(["default",0,b])}];

//# sourceMappingURL=projects_astralis-nextjs_src_app_a895177a._.js.map