module.exports=[270406,(a,b,c)=>{b.exports=a.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},814747,(a,b,c)=>{b.exports=a.x("path",()=>require("path"))}];

//# sourceMappingURL=%5Broot-of-the-server%5D__dd7cc552._.js.map