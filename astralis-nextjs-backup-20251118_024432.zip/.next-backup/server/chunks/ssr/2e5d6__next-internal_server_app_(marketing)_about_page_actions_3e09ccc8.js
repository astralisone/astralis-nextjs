module.exports=[533842,(a,b,c)=>{}];

//# sourceMappingURL=2e5d6__next-internal_server_app_%28marketing%29_about_page_actions_3e09ccc8.js.map