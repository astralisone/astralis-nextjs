module.exports=[111630,(a,b,c)=>{}];

//# sourceMappingURL=9e3a1_astralis-nextjs__next-internal_server_app__not-found_page_actions_abc0f4e9.js.map