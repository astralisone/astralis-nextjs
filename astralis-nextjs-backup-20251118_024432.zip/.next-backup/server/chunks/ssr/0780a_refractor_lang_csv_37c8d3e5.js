module.exports=[710571,a=>{"use strict";function b(a){a.languages.csv={value:/[^\r\n,"]+|"(?:[^"]|"")*"(?!")/,punctuation:/,/}}b.displayName="csv",b.aliases=[],a.s(["default",()=>b])}];

//# sourceMappingURL=0780a_refractor_lang_csv_37c8d3e5.js.map