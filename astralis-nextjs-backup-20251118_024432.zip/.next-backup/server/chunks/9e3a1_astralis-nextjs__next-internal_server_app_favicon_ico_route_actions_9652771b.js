module.exports=[718922,(e,o,d)=>{}];

//# sourceMappingURL=9e3a1_astralis-nextjs__next-internal_server_app_favicon_ico_route_actions_9652771b.js.map